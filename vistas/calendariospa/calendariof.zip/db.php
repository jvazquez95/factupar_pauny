<?php
    $connection = mysqli_connect('localhost','root','','spa') or die(mysqli_error($connection));
?>