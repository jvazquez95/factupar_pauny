<?php
$connection = mysqli_connect('localhost','root','','spa2') or die(mysqli_error($connection));
?>